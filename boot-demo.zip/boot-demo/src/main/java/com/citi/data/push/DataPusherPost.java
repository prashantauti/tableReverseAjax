package com.citi.data.push;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.citi.muni.application.controller.User;
import com.citi.muni.application.processor.ResponseModel;

public class DataPusherPost {

	
    public static void main(String[] args) throws IOException
    {
        Map<String, String> vars = new HashMap<String, String>();
        vars.put("id", "JS01");

        try
        {
            RestTemplate rt = new RestTemplate();
            rt.getMessageConverters().add(new StringHttpMessageConverter());
            String uri = new String("http://localhost:8000/demo/welcome/{id}");
            User u = new User();
            u.setName("Johnathan M Smith");
            u.setUser("JS01");

            ResponseModel returns = rt.postForObject(uri, u, ResponseModel.class, vars);
            System.out.println(returns);

        }
        catch (HttpClientErrorException e)
        {
          e.printStackTrace();
        }
        catch(Exception e)
        {

        }
    }

}

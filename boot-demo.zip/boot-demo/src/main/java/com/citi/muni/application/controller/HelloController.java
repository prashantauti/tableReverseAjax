package com.citi.muni.application.controller;


import java.util.concurrent.Future;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.citi.muni.application.processor.RequestCallable;
import com.citi.muni.application.processor.ResponseModel;

@RestController
public class HelloController {

	@Autowired
	RequestCallable requestCallable;
	
	@RequestMapping(value = "/welcome/{id}", method = RequestMethod.POST)
	@ResponseBody
	public ResponseModel index(@PathVariable("id") String id, @RequestBody User user){
		
		ResponseModel responseModel = new ResponseModel("Sucess");
		try{						
			Future<ResponseModel> responseFuture = requestCallable.aSyncMethodCall(user);
			//responseModel = responseFuture.get();
		}catch(Exception excep){
			responseModel = new ResponseModel("Error");
		}
		System.out.println("hello");
		return responseModel;
	}
	
}

package com.citi.muni.application.processor;

import java.util.concurrent.Callable;
import java.util.concurrent.Future;

import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;

import com.citi.muni.application.controller.User;

@Service
public class RequestCallable {

	public static Integer i= 1;
	
	public RequestCallable() {	
	}
	
	@Async
	public Future<ResponseModel> aSyncMethodCall(User user) throws Exception {
		
		System.out.println("Start of Sequential Processing");		
		ResponseModel responseModel = new ResponseModel("Sucess1");
		responseModel.setOutput(user.toString() + " " + i);		
		System.out.println("End of Sequential Processing");
		
		return new AsyncResult<ResponseModel>(responseModel);
	}

}

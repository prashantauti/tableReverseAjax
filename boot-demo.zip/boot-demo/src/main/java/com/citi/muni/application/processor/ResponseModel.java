package com.citi.muni.application.processor;

public class ResponseModel {

	String output;

	public String getOutput() {
		return output;
	}

	public void setOutput(String output) {
		this.output = output;
	}
	
	@Override
	public String toString() {
		return output;
	}
	
	public ResponseModel(String output) {
		this.output = output;
	}
}

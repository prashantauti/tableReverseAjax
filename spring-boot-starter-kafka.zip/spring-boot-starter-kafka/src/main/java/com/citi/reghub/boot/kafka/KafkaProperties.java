package com.citi.reghub.boot.kafka;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.NestedConfigurationProperty;

@ConfigurationProperties(prefix = KafkaProperties.KAFKA_PREFIX)
public class KafkaProperties {

	public static final String KAFKA_PREFIX = "kafka";

	private boolean debug = false;

	@NestedConfigurationProperty
	private Producer producer = new Producer();

	public boolean isDebug() {
		return debug;
	}

	public void setDebug(boolean debug) {
		this.debug = debug;
	}

	public Producer getProducer() {
		return producer;
	}

	public void setProducer(Producer producer) {
		this.producer = producer;
	}

	public static class Producer {

		private String bootstrapServer;
		private String retries;
		private String batchSize;
		private String lingerMs;
		private String bufferMemory;
		private String keySerializerClass;
		private String valueSerializerClass;
		private String maxBlockMs;

		public String getLingerMs() {
			return lingerMs;
		}

		public void setLingerMs(String lingerMs) {
			this.lingerMs = lingerMs;
		}

		public String getMaxBlockMs() {
			return maxBlockMs;
		}

		public void setMaxBlockMs(String maxBlockMs) {
			this.maxBlockMs = maxBlockMs;
		}

		public String getBootstrapServer() {
			return bootstrapServer;
		}

		public void setBootstrapServer(String bootstrapServer) {
			this.bootstrapServer = bootstrapServer;
		}

		public String getKeySerializerClass() {
			return keySerializerClass;
		}

		public void setKeySerializerClass(String keySerializerClass) {
			this.keySerializerClass = keySerializerClass;
		}

		public String getValueSerializerClass() {
			return valueSerializerClass;
		}

		public void setValueSerializerClass(String valueSerializerClass) {
			this.valueSerializerClass = valueSerializerClass;
		}

		public String getRetries() {
			return retries;
		}

		public void setRetries(String retries) {
			this.retries = retries;
		}

		public String getBatchSize() {
			return batchSize;
		}

		public void setBatchSize(String batchSize) {
			this.batchSize = batchSize;
		}

		public String getBufferMemory() {
			return bufferMemory;
		}

		public void setBufferMemory(String bufferMemory) {
			this.bufferMemory = bufferMemory;
		}

	}
}

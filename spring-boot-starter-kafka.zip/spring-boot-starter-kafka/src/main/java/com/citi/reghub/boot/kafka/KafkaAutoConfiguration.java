package com.citi.reghub.boot.kafka;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.apache.commons.lang3.math.NumberUtils;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;


@Configuration
@EnableConfigurationProperties(KafkaProperties.class)
@EnableKafka
@SuppressWarnings("rawtypes")
public class KafkaAutoConfiguration {

	@Autowired
	private KafkaProperties kafkaProperties;
	
	
	@Bean
	public ProducerFactory producerFactory() {
		return new DefaultKafkaProducerFactory<>(producerConfigs());
	}

	@Bean
	public Map<String, Object> producerConfigs() {
		Map<String, Object> props = new HashMap<>();
		props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, getValueOrDefault(kafkaProperties.getProducer().getBootstrapServer(),"localhost:9092"));
		props.put(ProducerConfig.RETRIES_CONFIG, NumberUtils.toInt(kafkaProperties.getProducer().getRetries(),1));
		props.put(ProducerConfig.BATCH_SIZE_CONFIG, NumberUtils.toInt(kafkaProperties.getProducer().getBatchSize(),16384));
		props.put(ProducerConfig.LINGER_MS_CONFIG, NumberUtils.toLong(kafkaProperties.getProducer().getLingerMs(),0L));
		props.put(ProducerConfig.MAX_BLOCK_MS_CONFIG, NumberUtils.toLong(kafkaProperties.getProducer().getMaxBlockMs(),60*1000L));
		props.put(ProducerConfig.BUFFER_MEMORY_CONFIG, NumberUtils.toLong(kafkaProperties.getProducer().getBufferMemory(),32 * 1024 * 1024L));
		props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, getValueOrDefault(kafkaProperties.getProducer().getKeySerializerClass(),
				"org.apache.kafka.common.serialization.StringSerializer"));
		props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, getValueOrDefault(kafkaProperties.getProducer().getValueSerializerClass(),
				"org.apache.kafka.common.serialization.StringSerializer"));
		return props;
	}

	private String getValueOrDefault(String originalValue, String defaultValue) {
		  return Optional.ofNullable(originalValue)
		      .filter(s -> s != null && !s.isEmpty()).orElse(defaultValue);
	}

	@SuppressWarnings("unchecked")
	@Bean
	public KafkaTemplate kafkaTemplate() {
		return new KafkaTemplate(producerFactory());
	}

}
